package com.ivan.communitymanagementsys.constant;

public class ApplicationsStatusConstant {
//    0待审核、1已批准、2已拒绝
    public static final Integer PRESIDENT = 0;
    public static final Integer APPROVED = 1;
    public static final Integer REJECTED = 2;
}
