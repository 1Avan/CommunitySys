package com.ivan.communitymanagementsys.constant;

public class RoleConstant {
//    用户角色（1.管理员 2.社长 3.普通用户）

    public static final Integer  ADMINISTRATORS = 1;
    public static final Integer PRESIDENT = 2;
    public static final Integer ORDINARY = 3;

}
