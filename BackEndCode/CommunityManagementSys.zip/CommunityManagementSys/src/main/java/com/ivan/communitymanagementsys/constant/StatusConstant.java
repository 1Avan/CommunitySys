package com.ivan.communitymanagementsys.constant;

public class StatusConstant {
    //用户是否正常（1.是 2.否）
    public static final Integer ENABLE = 1;
    public static final Integer DISABLE = 2;

}
