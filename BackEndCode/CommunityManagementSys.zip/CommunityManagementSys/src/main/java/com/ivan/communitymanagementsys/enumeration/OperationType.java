package com.ivan.communitymanagementsys.enumeration;

public enum OperationType {
    /**
     * 更新操作
     */
    UPDATE,

    /**
     * 新增操作
     */
    INSERT
}
